"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  Eye,
  MoreHorizontal,
  CheckCircle,
  XCircle,
  Clock,
  User,
  Mail,
  Phone,
  School,
  GraduationCap,
  FileText,
  ImageIcon,
  CreditCard,
  ArrowUpDown,
  Filter,
  Calendar,
  FileSpreadsheet,
  Users,
  CheckSquare,
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { showErrorToast, showSuccessToast, withRetry } from "@/lib/error-handler"
import { ErrorBoundary } from "@/components/error-boundary"
import { useToast } from "@/hooks/use-toast"
import type { UnifiedRegistration } from "./page"

const FileViewer = ({ url, alt, className }: { url: string | null; alt: string; className?: string }) => {
  if (!url) {
    return (
      <div className={`bg-gray-100 rounded-lg flex items-center justify-center ${className}`}>
        <FileText className="w-8 h-8 text-gray-400" />
      </div>
    )
  }

  const getFileType = (url: string): "image" | "pdf" | "unknown" => {
    const extension = url.split(".").pop()?.toLowerCase()
    if (["jpg", "jpeg", "png", "gif", "webp"].includes(extension || "")) {
      return "image"
    } else if (extension === "pdf") {
      return "pdf"
    }
    return "unknown"
  }

  const fileType = getFileType(url)

  if (fileType === "image") {
    return (
      <img
        src={url || "/placeholder.svg"}
        alt={alt}
        className={`object-cover rounded-lg ${className}`}
        onError={(e) => {
          ;(e.target as HTMLImageElement).src = "/placeholder.svg"
        }}
      />
    )
  } else if (fileType === "pdf") {
    return (
      <div className={`bg-red-50 rounded-lg flex flex-col items-center justify-center ${className}`}>
        <FileText className="w-8 h-8 text-red-500 mb-2" />
        <span className="text-xs text-red-700">PDF File</span>
      </div>
    )
  }

  return (
    <div className={`bg-gray-100 rounded-lg flex items-center justify-center ${className}`}>
      <FileText className="w-8 h-8 text-gray-400" />
    </div>
  )
}

export default function UnifiedManagementClient({
  initialRegistrations,
  stats,
  ospSubjects, // Terima props baru
}: {
  initialRegistrations: UnifiedRegistration[]
  stats: {
    total: number
    approved: number
    pending: number
    rejected: number
    approvedToday: number
    rejectedToday: number
  }
  ospSubjects: { id: string; name: string }[] // Definisikan tipe props baru
}) {
  const [registrations, setRegistrations] = useState<UnifiedRegistration[]>(initialRegistrations)
  const [selectedRegistration, setSelectedRegistration] = useState<UnifiedRegistration | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [competitionFilter, setCompetitionFilter] = useState("all")
  const [educationFilter, setEducationFilter] = useState("all")
  const [dateFromFilter, setDateFromFilter] = useState("")
  const [dateToFilter, setDateToFilter] = useState("")
  const [sortBy, setSortBy] = useState("created_at")
  const [sortOrder, setSortOrder] = useState("desc")
  const [loading, setLoading] = useState(false)
  const [showDetailDialog, setShowDetailDialog] = useState(false)
  const [statusChangeReason, setStatusChangeReason] = useState("")

  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [showBulkDialog, setShowBulkDialog] = useState(false)
  const [bulkStatus, setBulkStatus] = useState("")
  const [bulkReason, setBulkReason] = useState("")
  const [showExportDialog, setShowExportDialog] = useState(false)
  const [exportFormat, setExportFormat] = useState("xlsx")
  const [includeTeamMembers, setIncludeTeamMembers] = useState(false)

  const { toast } = useToast()
  const supabase = createClient()

  // Helper for deep value access in sorting
  const dlv = (obj: any, key: string) => key.split(".").reduce((acc, curr) => acc && acc[curr], obj)

  const filteredRegistrations = registrations
    .filter((registration) => {
      const matchesSearch =
        registration.profiles.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        registration.profiles.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        registration.profiles.school_institution.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (registration.profiles.identity_number && registration.profiles.identity_number.includes(searchTerm))

      const matchesStatus = statusFilter === "all" || registration.status === statusFilter
      const matchesCompetition = competitionFilter === "all" || registration.competitions.code === competitionFilter
      const matchesEducation = educationFilter === "all" || registration.profiles.education_level === educationFilter

      const matchesDateFrom = !dateFromFilter || new Date(registration.created_at) >= new Date(dateFromFilter)
      const matchesDateTo = !dateToFilter || new Date(registration.created_at) <= new Date(dateToFilter)

      return (
        matchesSearch && matchesStatus && matchesCompetition && matchesEducation && matchesDateFrom && matchesDateTo
      )
    })
    .sort((a, b) => {
      const aValue = sortBy.includes(".") ? dlv(a, sortBy) : (a[sortBy as keyof UnifiedRegistration] as any)
      const bValue = sortBy.includes(".") ? dlv(b, sortBy) : (b[sortBy as keyof UnifiedRegistration] as any)

      if (sortOrder === "asc") {
        return aValue > bValue ? 1 : -1
      } else {
        return aValue < bValue ? 1 : -1
      }
    })

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedIds(filteredRegistrations.map((reg) => reg.id))
    } else {
      setSelectedIds([])
    }
  }

  const handleSelectOne = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedIds([...selectedIds, id])
    } else {
      setSelectedIds(selectedIds.filter((selectedId) => selectedId !== id))
    }
  }

  const handleBulkApproval = async () => {
    if (selectedIds.length === 0 || !bulkStatus) return

    setLoading(true)
    try {
      const response = await fetch("/api/admin/bulk-approval", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          registrationIds: selectedIds,
          status: bulkStatus,
          reason: bulkReason,
        }),
      })

      if (response.ok) {
        const result = await response.json()

        // Update local state
        setRegistrations(
          registrations.map((reg) =>
            selectedIds.includes(reg.id) ? { ...reg, status: bulkStatus, updated_at: new Date().toISOString() } : reg,
          ),
        )

        showSuccessToast(result.message)
        setShowBulkDialog(false)
        setSelectedIds([])
        setBulkStatus("")
        setBulkReason("")
      } else {
        throw new Error("Failed to update registrations")
      }
    } catch (error) {
      showErrorToast(error, "handleBulkApproval")
    } finally {
      setLoading(false)
    }
  }

  // ▼▼▼ PERBAIKI FUNGSI INI ▼▼▼
  const handleAdvancedExport = async () => {
    setLoading(true)
    try {
      // Map data yang sudah difilter untuk menyisipkan nama bidang OSP
      const dataToExport = filteredRegistrations.map(reg => {
        const ospSubject = reg.competitions.code === 'OSP' && reg.selected_subject_id
          ? ospSubjects.find(s => s.id === reg.selected_subject_id)?.name
          : null;
        
        return {
          ...reg,
          osp_subject_name: ospSubject || '-', // Tambahkan field baru
        };
      });

      const response = await fetch("/api/admin/export", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          format: exportFormat,
          // Kirim data yang sudah diolah, bukan filter mentah
          data: dataToExport, 
          includeTeamMembers,
        }),
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const link = document.createElement("a")
        link.href = url

        const filename =
          exportFormat === "xlsx"
            ? `UISO_2025_Export_${new Date().toISOString().split("T")[0]}.xlsx`
            : `UISO_2025_Export_${new Date().toISOString().split("T")[0]}.csv`

        link.download = filename
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        window.URL.revokeObjectURL(url)

        showSuccessToast(`Data berhasil diekspor dalam format ${exportFormat.toUpperCase()}`)
        setShowExportDialog(false)
      } else {
        // Coba baca pesan error dari server jika ada
        const errorData = await response.json().catch(() => ({ message: "Export failed" }));
        throw new Error(errorData.message);
      }
    } catch (error) {
      showErrorToast(error, "handleAdvancedExport")
    } finally {
      setLoading(false)
    }
  }
  // ▲▲▲ BATAS AKHIR PERUBAHAN ▲▲▲

  const handleStatusChange = async (registrationId: string, newStatus: string) => {
    setLoading(true)
    try {
      await withRetry(async () => {
        const { error } = await supabase
          .from("registrations")
          .update({
            status: newStatus,
            updated_at: new Date().toISOString(),
          })
          .eq("id", registrationId)

        if (error) throw error
      })

      setRegistrations(
        registrations.map((reg) =>
          reg.id === registrationId ? { ...reg, status: newStatus, updated_at: new Date().toISOString() } : reg,
        ),
      )

      showSuccessToast(`Status berhasil diubah menjadi ${newStatus}`)
      setStatusChangeReason("")
    } catch (error) {
      showErrorToast(error, "handleStatusChange")
    } finally {
      setLoading(false)
    }
  }

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortBy(column)
      setSortOrder("asc")
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            <CheckCircle className="w-3 h-3 mr-1" />
            Disetujui
          </Badge>
        )
      case "rejected":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            <XCircle className="w-3 h-3 mr-1" />
            Ditolak
          </Badge>
        )
      default:
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            <Clock className="w-3 h-3 mr-1" />
            Menunggu
          </Badge>
        )
    }
  }

  const handleViewDetail = (registration: UnifiedRegistration) => {
    setSelectedRegistration(registration)
    setShowDetailDialog(true)
  }

  return (
    <ErrorBoundary>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Manajemen Terpadu</h2>
            <p className="text-muted-foreground">
              Kelola akun peserta dan persetujuan pendaftaran dalam satu dashboard
            </p>
          </div>
          <div className="flex gap-2">
            {selectedIds.length > 0 && (
              <Button
                variant="outline"
                onClick={() => setShowBulkDialog(true)}
                className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
              >
                <Users className="mr-2 h-4 w-4" />
                Aksi Massal ({selectedIds.length})
              </Button>
            )}
            <Button variant="outline" onClick={() => setShowExportDialog(true)}>
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Export Lanjutan
            </Button>
          </div>
        </div>

        {/* Comprehensive Stats */}
        <div className="grid gap-4 md:grid-cols-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Pendaftar</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Disetujui</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.approved}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Menunggu</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Ditolak</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.rejected}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Disetujui Hari Ini</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">{stats.approvedToday}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Ditolak Hari Ini</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-500">{stats.rejectedToday}</div>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Filter & Search Controls */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filter & Pencarian Lanjutan
            </CardTitle>
            <CardDescription>
              Gunakan filter untuk mencari dan mengelola pendaftaran dengan lebih detail
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* First row - Search and basic filters */}
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Cari nama, email, sekolah, atau nomor identitas..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full md:w-[180px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Status</SelectItem>
                    <SelectItem value="pending">Menunggu</SelectItem>
                    <SelectItem value="approved">Disetujui</SelectItem>
                    <SelectItem value="rejected">Ditolak</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={competitionFilter} onValueChange={setCompetitionFilter}>
                  <SelectTrigger className="w-full md:w-[180px]">
                    <SelectValue placeholder="Kompetisi" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Kompetisi</SelectItem>
                    <SelectItem value="OSP">OSP</SelectItem>
                    <SelectItem value="EGK">EGK</SelectItem>
                    <SelectItem value="SCC">SCC</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex flex-col md:flex-row gap-4">
                <Select value={educationFilter} onValueChange={setEducationFilter}>
                  <SelectTrigger className="w-full md:w-[200px]">
                    <SelectValue placeholder="Jenjang Pendidikan" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Jenjang</SelectItem>
                    <SelectItem value="SMA/Sederajat">SMA/Sederajat</SelectItem>
                    <SelectItem value="Mahasiswa/i">Mahasiswa/i</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex gap-2 items-center">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <Label className="text-sm whitespace-nowrap">Dari:</Label>
                  <Input
                    type="date"
                    value={dateFromFilter}
                    onChange={(e) => setDateFromFilter(e.target.value)}
                    className="w-full md:w-[150px]"
                  />
                  <Label className="text-sm whitespace-nowrap">Sampai:</Label>
                  <Input
                    type="date"
                    value={dateToFilter}
                    onChange={(e) => setDateToFilter(e.target.value)}
                    className="w-full md:w-[150px]"
                  />
                </div>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setStatusFilter("all")
                    setCompetitionFilter("all")
                    setEducationFilter("all")
                    setDateFromFilter("")
                    setDateToFilter("")
                  }}
                  className="whitespace-nowrap"
                >
                  Reset Filter
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Management Table */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Data Pendaftaran ({filteredRegistrations.length})</CardTitle>
                <CardDescription>Kelola semua pendaftaran dengan status yang dapat diubah</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  checked={selectedIds.length === filteredRegistrations.length && filteredRegistrations.length > 0}
                  onCheckedChange={handleSelectAll}
                />
                <Label className="text-sm">Pilih Semua</Label>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="w-[50px]">
                      <CheckSquare className="h-4 w-4" />
                    </TableHead>
                    <TableHead className="w-[200px]">
                      <Button
                        variant="ghost"
                        onClick={() => handleSort("profiles.full_name")}
                        className="h-auto p-0 font-semibold"
                      >
                        Nama Peserta
                        <ArrowUpDown className="ml-2 h-4 w-4" />
                      </Button>
                    </TableHead>
                    <TableHead>
                      <Button
                        variant="ghost"
                        onClick={() => handleSort("competitions.code")}
                        className="h-auto p-0 font-semibold"
                      >
                        Kompetisi
                        <ArrowUpDown className="ml-2 h-4 w-4" />
                      </Button>
                    </TableHead>
                    <TableHead>Bidang OSP</TableHead>
                    <TableHead>
                      <Button
                        variant="ghost"
                        onClick={() => handleSort("profiles.education_level")}
                        className="h-auto p-0 font-semibold"
                      >
                        Jenjang
                        <ArrowUpDown className="ml-2 h-4 w-4" />
                      </Button>
                    </TableHead>
                    <TableHead>Sekolah/Institusi</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>
                      <Button
                        variant="ghost"
                        onClick={() => handleSort("created_at")}
                        className="h-auto p-0 font-semibold"
                      >
                        Tanggal Daftar
                        <ArrowUpDown className="ml-2 h-4 w-4" />
                      </Button>
                    </TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ubah Status</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRegistrations.map((registration) => (
                    <TableRow key={registration.id} className="hover:bg-gray-50">
                      <TableCell>
                        <Checkbox
                          checked={selectedIds.includes(registration.id)}
                          onCheckedChange={(checked) => handleSelectOne(registration.id, checked as boolean)}
                        />
                      </TableCell>
                      <TableCell className="font-medium">
                        <div>
                          <p className="font-semibold">{registration.profiles.full_name}</p>
                          <p className="text-sm text-gray-500">{registration.profiles.identity_number}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="font-medium">
                          {registration.competitions.name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                          {(() => {
                            if (registration.competitions.code !== 'OSP' || !registration.selected_subject_id) return '-';
                            const subject = ospSubjects.find(s => s.id === registration.selected_subject_id);
                            return <Badge variant="outline">{subject?.name || 'ID Tidak Dikenal'}</Badge>;
                          })()}
                        </TableCell>
                      <TableCell>
                        <Badge variant="outline">{registration.profiles.education_level}</Badge>
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate" title={registration.profiles.school_institution}>
                        {registration.profiles.school_institution}
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate" title={registration.profiles.email}>
                        {registration.profiles.email}
                      </TableCell>
                      <TableCell>{new Date(registration.created_at).toLocaleDateString("id-ID")}</TableCell>
                      <TableCell>{getStatusBadge(registration.status)}</TableCell>
                      <TableCell>
                        <Select
                          value={registration.status}
                          onValueChange={(newStatus) => handleStatusChange(registration.id, newStatus)}
                          disabled={loading}
                        >
                          <SelectTrigger className="w-[120px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Menunggu</SelectItem>
                            <SelectItem value="approved">Setujui</SelectItem>
                            <SelectItem value="rejected">Tolak</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Aksi</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleViewDetail(registration)}>
                              <Eye className="mr-2 h-4 w-4" />
                              Lihat Detail
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => handleStatusChange(registration.id, "approved")}>
                              <CheckCircle className="mr-2 h-4 w-4" />
                              Setujui Cepat
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-red-600"
                              onClick={() => handleStatusChange(registration.id, "rejected")}
                            >
                              <XCircle className="mr-2 h-4 w-4" />
                              Tolak Cepat
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {filteredRegistrations.length === 0 && (
              <div className="text-center py-8">
                <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Tidak Ada Data Ditemukan</h3>
                <p className="text-muted-foreground">
                  {searchTerm || statusFilter !== "all" || competitionFilter !== "all"
                    ? "Coba ubah filter atau kata kunci pencarian"
                    : "Belum ada pendaftaran dalam sistem"}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={showBulkDialog} onOpenChange={setShowBulkDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Aksi Massal</DialogTitle>
              <DialogDescription>Ubah status untuk {selectedIds.length} pendaftaran yang dipilih</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="bulk-status">Status Baru</Label>
                <Select value={bulkStatus} onValueChange={setBulkStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="approved">Setujui Semua</SelectItem>
                    <SelectItem value="rejected">Tolak Semua</SelectItem>
                    <SelectItem value="pending">Kembalikan ke Menunggu</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="bulk-reason">Catatan (Opsional)</Label>
                <Input
                  id="bulk-reason"
                  placeholder="Alasan perubahan status..."
                  value={bulkReason}
                  onChange={(e) => setBulkReason(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowBulkDialog(false)}>
                Batal
              </Button>
              <Button onClick={handleBulkApproval} disabled={loading || !bulkStatus}>
                {loading ? "Memproses..." : "Terapkan"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Export Data Lanjutan</DialogTitle>
              <DialogDescription>Pilih format dan opsi export yang diinginkan</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Format Export</Label>
                <Select value={exportFormat} onValueChange={setExportFormat}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="xlsx">Excel (.xlsx) - Rekomendasi</SelectItem>
                    <SelectItem value="csv">CSV (.csv)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="include-team" checked={includeTeamMembers} onCheckedChange={(checked) => setIncludeTeamMembers(Boolean(checked))} />
                <Label htmlFor="include-team">Sertakan data anggota tim (untuk kompetisi tim)</Label>
              </div>
              <div className="text-sm text-muted-foreground">
                <p>
                  <strong>Data yang akan diexport:</strong> {filteredRegistrations.length} pendaftaran
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowExportDialog(false)}>
                Batal
              </Button>
              <Button onClick={handleAdvancedExport} disabled={loading}>
                {loading ? "Mengexport..." : "Export"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Detail Dialog */}
        <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Detail Pendaftaran - {selectedRegistration?.profiles.full_name}</DialogTitle>
              <DialogDescription>Informasi lengkap peserta dan berkas pendaftaran</DialogDescription>
            </DialogHeader>

            {selectedRegistration && (
              <Tabs defaultValue="info" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="info">Informasi Peserta</TabsTrigger>
                  <TabsTrigger value="files">Berkas</TabsTrigger>
                  {selectedRegistration.team_members && selectedRegistration.team_members.length > 0 && (
                    <TabsTrigger value="team">Anggota Tim</TabsTrigger>
                  )}
                </TabsList>

                <TabsContent value="info" className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <User className="w-5 h-5" />
                      Informasi Dasar
                    </h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label className="text-sm font-medium flex items-center gap-2">
                          <User className="w-4 h-4" />
                          Nama Lengkap
                        </Label>
                        <p className="text-sm bg-gray-50 p-2 rounded">{selectedRegistration.profiles.full_name}</p>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-medium flex items-center gap-2">
                          <Mail className="w-4 h-4" />
                          Email
                        </Label>
                        <p className="text-sm bg-gray-50 p-2 rounded">{selectedRegistration.profiles.email}</p>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-medium flex items-center gap-2">
                          <School className="w-4 h-4" />
                          Sekolah/Institusi
                        </Label>
                        <p className="text-sm bg-gray-50 p-2 rounded">
                          {selectedRegistration.profiles.school_institution}
                        </p>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-medium flex items-center gap-2">
                          <GraduationCap className="w-4 h-4" />
                          Jenjang Pendidikan
                        </Label>
                        <p className="text-sm bg-gray-50 p-2 rounded">
                          {selectedRegistration.profiles.education_level}
                        </p>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Nomor Identitas</Label>
                        <p className="text-sm bg-gray-50 p-2 rounded">
                          {selectedRegistration.profiles.identity_number}
                        </p>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-medium flex items-center gap-2">
                          <Phone className="w-4 h-4" />
                          No. HP (Aktif WhatsApp)
                        </Label>
                        <p className="text-sm bg-gray-50 p-2 rounded">
                          {selectedRegistration.profiles.phone || selectedRegistration.phone || "Belum diisi"}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <GraduationCap className="w-5 h-5" />
                      Informasi Kompetisi
                    </h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Kompetisi</Label>
                        <p className="text-sm bg-gray-50 p-2 rounded">{selectedRegistration.competitions.name}</p>
                      </div>
                      {selectedRegistration.competitions.code === "OSP" && selectedRegistration.selected_subject_id && (
                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Bidang OSP</Label>
                          <p className="text-sm bg-gray-50 p-2 rounded">
                            {ospSubjects.find(s => s.id === selectedRegistration.selected_subject_id)?.name || "ID Tidak Dikenal"}
                          </p>
                        </div>
                      )}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Status Pendaftaran</Label>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(selectedRegistration.status)}
                          <span className="text-xs text-gray-500">
                            Diperbarui: {new Date(selectedRegistration.updated_at).toLocaleDateString("id-ID")}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="files" className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-3">
                    {/* Kartu Identitas */}
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <ImageIcon className="w-4 h-4" />
                          Kartu Identitas
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="aspect-video mb-2">
                          <FileViewer
                            url={selectedRegistration.identity_card_url}
                            alt="Kartu Identitas"
                            className="w-full h-full"
                          />
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full bg-transparent"
                          onClick={() =>
                            selectedRegistration.identity_card_url &&
                            window.open(selectedRegistration.identity_card_url, "_blank")
                          }
                          disabled={!selectedRegistration.identity_card_url}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Lihat
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Bukti Engagement */}
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <FileText className="w-4 h-4" />
                          Bukti Engagement
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="aspect-video mb-2">
                          <FileViewer
                            url={selectedRegistration.engagement_proof_url}
                            alt="Bukti Engagement"
                            className="w-full h-full"
                          />
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full bg-transparent"
                          onClick={() =>
                            selectedRegistration.engagement_proof_url &&
                            window.open(selectedRegistration.engagement_proof_url, "_blank")
                          }
                          disabled={!selectedRegistration.engagement_proof_url}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Lihat
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Bukti Pembayaran */}
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <CreditCard className="w-4 h-4" />
                          Bukti Pembayaran
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="aspect-video mb-2">
                          <FileViewer
                            url={selectedRegistration.payment_proof_url}
                            alt="Bukti Pembayaran"
                            className="w-full h-full"
                          />
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full bg-transparent"
                          onClick={() =>
                            selectedRegistration.payment_proof_url &&
                            window.open(selectedRegistration.payment_proof_url, "_blank")
                          }
                          disabled={!selectedRegistration.payment_proof_url}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Lihat
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                {selectedRegistration.team_members && selectedRegistration.team_members.length > 0 && (
                  <TabsContent value="team" className="space-y-4">
                    <div className="space-y-4">
                      {selectedRegistration.team_members.map((member, index) => (
                        <Card key={member.id}>
                          <CardHeader>
                            <CardTitle className="text-base">Anggota {index + 1}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="grid gap-4 md:grid-cols-2">
                              <div>
                                <Label className="text-sm font-medium">Nama</Label>
                                <p className="text-sm bg-gray-50 p-2 rounded mt-1">{member.full_name}</p>
                              </div>
                              <div>
                                <Label className="text-sm font-medium">Email</Label>
                                <p className="text-sm bg-gray-50 p-2 rounded mt-1">{member.email || "Belum diisi"}</p>
                              </div>
                              <div>
                                <Label className="text-sm font-medium">No. HP</Label>
                                <p className="text-sm bg-gray-50 p-2 rounded mt-1">{member.phone || "Belum diisi"}</p>
                              </div>
                              <div>
                                <Label className="text-sm font-medium">Sekolah/Institusi</Label>
                                <p className="text-sm bg-gray-50 p-2 rounded mt-1">
                                  {member.school_institution || "Belum diisi"}
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>
                )}
              </Tabs>
            )}

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDetailDialog(false)}>
                Tutup
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </ErrorBoundary>
  )
}
