"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Home, FileText, Upload, Menu, LogOut, User } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { usePathname, useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

const sidebarItems = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: Home,
  },
  {
    title: "Pendaftaran Kompetisi",
    href: "/dashboard/pendaftaran",
    icon: FileText,
  },
  // {
  //   title: "Submisi",
  //   href: "/dashboard/submisi",
  //   icon: Upload,
  // },
]

interface DashboardLayoutClientProps {
  children: React.ReactNode
  user: any
  profile: any
}

export default function DashboardLayoutClient({ children, user, profile }: DashboardLayoutClientProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()
  

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/login")
  }

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      {/* Logo */}
      <div className="flex h-16 items-center border-b px-6">
        <div className="flex items-center gap-3">
          <Image
            src="/images/uiso-logo.png"
            alt="UISO 2025 Logo"
            width={32}
            height={32}
            className="w-8 h-8 object-contain"
          />
          <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent font-bold text-lg">
            UISO 2025
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-2 p-4">
  <TooltipProvider delayDuration={100}>
    {sidebarItems.map((item) => {
      const isActive = pathname === item.href
      const isRegistrationLink = item.href === "/dashboard/pendaftaran"
      const isDisabled = isRegistrationLink && !isProfileComplete

      const linkClasses = `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
        isActive ? "bg-primary text-primary-foreground" : "text-gray-700 hover:bg-gray-100 hover:text-gray-900"
      } ${isDisabled ? "cursor-not-allowed opacity-50" : ""}`

      if (isDisabled) {
        return (
          <Tooltip key={item.href}>
            <TooltipTrigger asChild>
              <div className={linkClasses}>
                <item.icon className="h-4 w-4" />
                {item.title}
              </div>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>Lengkapi profil Anda untuk membuka menu ini.</p>
            </TooltipContent>
          </Tooltip>
        )
      }

      return (
        <Link key={item.href} href={item.href} className={linkClasses} onClick={() => setSidebarOpen(false)}>
          <item.icon className="h-4 w-4" />
          {item.title}
        </Link>
      )
    })}
  </TooltipProvider>
</nav>

      {/* User Section */}
      <div className="border-t p-4">
        <div className="flex items-center gap-3 text-sm">
          <Avatar className="h-8 w-8">
            <AvatarFallback>
              {profile?.full_name
                ?.split(" ")
                .map((n: string) => n[0])
                .join("")
                .toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="font-medium text-gray-900 truncate">{profile?.full_name || "User"}</p>
            <p className="text-gray-500 truncate">{user?.email}</p>
          </div>
        </div>
      </div>
    </div>
  )

  const [isProfileComplete, setIsProfileComplete] = useState(false)
    useEffect(() => {
    const checkProfileCompleteness = () => {
        if (!profile) {
            setIsProfileComplete(false)
            return
        }
        const requiredFields = [
            "full_name",
            "school_institution",
            "identity_number",
            "phone",
            "tempat_lahir",
            "tanggal_lahir",
            "jenis_kelamin",
            "alamat",
        ]
        const isComplete = requiredFields.every((field) => profile[field])
        setIsProfileComplete(isComplete)
    }

    checkProfileCompleteness()
  }, [profile])

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Desktop Sidebar */}
      <div className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0">
        <div className="flex flex-col flex-grow bg-white border-r border-gray-200 overflow-y-auto">
          <SidebarContent />
        </div>
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-64 p-0">
          <SidebarContent />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <div className="flex flex-1 flex-col lg:pl-64">
        {/* Top Header */}
        <header className="flex h-16 items-center justify-between border-b border-gray-200 bg-white px-6">
          <div className="flex items-center gap-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0">
                <SidebarContent />
              </SheetContent>
            </Sheet>
            <h1 className="text-xl font-semibold text-gray-900">
              {sidebarItems.find((item) => item.href === pathname)?.title || "Dashboard"}
            </h1>
          </div>

          <div className="flex items-center gap-4">
            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      {profile?.full_name
                        ?.split(" ")
                        .map((n: string) => n[0])
                        .join("")
                        .toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{profile?.full_name || "User"}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/profile">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  )
}
