"use client"

import { useState, useEffect } from "react"

export function CountdownSection() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  })

  useEffect(() => {
    // Set target date to March 15, 2025
    const targetDate = new Date("2025-03-15T00:00:00").getTime()

    const timer = setInterval(() => {
      const now = new Date().getTime()
      const difference = targetDate - now

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        })
      }
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <section
      id="beranda"
      className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-tertiary/10 to-accent/10 pt-20"
    >
      <div className="max-w-6xl mx-auto px-6 text-center">
        <div className="mb-8">
          <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent mb-4">
            UISO 2025
          </h1>
          <p className="text-xl md:text-2xl text-primary font-semibold mb-2">UI Science Olympiad</p>
          <p className="text-lg text-primary">Kompetisi Sains Tingkat Nasional</p>
        </div>

        <div className="mb-12">
          <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-8">
            Hitung Mundur Menuju UISO 2025!
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
            {[
              { label: "Hari", value: timeLeft.days },
              { label: "Jam", value: timeLeft.hours },
              { label: "Menit", value: timeLeft.minutes },
              { label: "Detik", value: timeLeft.seconds },
            ].map((item) => (
              <div key={item.label} className="bg-white rounded-xl shadow-lg p-6 border-t-4 border-primary">
                <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-2">
                  {item.value.toString().padStart(2, "0")}
                </div>
                <div className="text-primary font-medium">{item.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <p className="text-lg text-primary">
            Bergabunglah dengan ribuan siswa terbaik Indonesia dalam kompetisi sains terbesar!
          </p>
          <button className="bg-gradient-to-r from-accent to-accent-light hover:from-accent-dark hover:to-accent text-accent-foreground font-bold px-8 py-4 rounded-full text-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
            Daftar Sekarang
          </button>
        </div>
      </div>
    </section>
  )
}
