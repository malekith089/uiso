import { Award, Users, Trophy, Target } from "lucide-react"

export function AboutSection() {
  const features = [
    {
      icon: <Award className="w-8 h-8" />,
      title: "Kompetisi Bergengsi",
      description: "Ajang kompetisi sains tingkat nasional yang diakui secara resmi",
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Ribuan Peserta",
      description: "Diikuti oleh ribuan siswa terbaik dari seluruh Indonesia",
    },
    {
      icon: <Trophy className="w-8 h-8" />,
      title: "Hadiah Menarik",
      description: "Total hadiah puluhan juta rupiah untuk para pemenang",
    },
    {
      icon: <Target className="w-8 h-8" />,
      title: "Pengembangan Diri",
      description: "Kesempatan mengembangkan kemampuan sains dan teknologi",
    },
  ]

  return (
    <section id="tentang" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-6">
            Apa itu UISO?
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              UI Science Olympiad (UISO) adalah kompetisi sains tingkat nasional yang diselenggarakan oleh Universitas
              Indonesia. Acara ini bertujuan untuk mengembangkan minat dan bakat siswa dalam bidang sains dan teknologi,
              serta memberikan wadah bagi siswa-siswi terbaik Indonesia untuk berkompetisi dan menunjukkan kemampuan
              mereka.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              UISO menyelenggarakan berbagai kategori lomba yang mencakup Olimpiade Sains Pengetahuan (OSP), Science
              Creative Competition (SCC), dan Environmental Green Knowledge (EGK). Setiap kategori dirancang untuk
              menguji kemampuan peserta dalam berbagai aspek sains dan teknologi.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center group">
              <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:from-primary/30 group-hover:to-accent/30 transition-all duration-300">
                <div className="text-primary">{feature.icon}</div>
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
